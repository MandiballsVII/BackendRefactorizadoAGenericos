package entidades;

public interface Formateable {
	String formatear();
}
