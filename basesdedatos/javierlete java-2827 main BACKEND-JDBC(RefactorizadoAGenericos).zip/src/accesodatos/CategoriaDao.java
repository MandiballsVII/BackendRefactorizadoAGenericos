package accesodatos;

import bibliotecas.Dao;
import entidades.Categoria;

public interface CategoriaDao extends Dao<Categoria> {

}
