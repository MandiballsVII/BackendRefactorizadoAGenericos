package bases;

import static java.lang.Math.*;

public class Matematicas {
	public static void main(String[] args) {
		System.out.println(5^2);
		
		System.out.println(pow(5, 2));
		System.out.println(sqrt(25));
	}
}
